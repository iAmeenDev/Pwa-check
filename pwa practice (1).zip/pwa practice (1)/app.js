let p = document.getElementById('div');
let btn = document.querySelector('button');
btn.addEventListener('click', () =>{
    p.textContent = 'oh shet js';
});

